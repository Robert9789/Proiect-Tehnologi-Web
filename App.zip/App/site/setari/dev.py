
from .common import *
#setările bazei de date
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

# setări de e-mail
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# django-cors-headers settings
CORS_ORIGIN_WHITELIST = ('localhost:3000', )
