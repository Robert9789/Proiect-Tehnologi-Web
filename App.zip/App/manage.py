import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError("Nu s-a putut importa Django. Sunteți sigur că este instalat și "
                          " este disponibil pe variabila de mediu PYTHONPATH? Ați "
                          "ați uitat să activați un mediu virtual?") from exc
    execute_from_command_line(sys.argv)
