
var django = django || {};
django.jQuery = jQuery.noConflict(true);
