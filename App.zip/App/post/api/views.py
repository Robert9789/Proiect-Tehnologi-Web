from rest_framework.filters import OrderingFilter, SearchFilter

from rest_framework.generics import (
    ListCreateAPIView,
    RetrieveUpdateDestroyAPIView,
)
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from rest_framework.views import APIView

from subjects.models import Subject

from .pagination import SubjectPageNumberPagination
from .permissions import IsAuthorOrReadOnly
from .serializers import SubjectSerializer


class SubjectListCreateAPIView(ListCreateAPIView):
    """
    Vizualizare care returnează o listă de subiecți pe baza rank_score, a unui anumit utilizator sau
    de către un anumit utilizator sau o anumită comisie etc. și se ocupă de crearea subiectelor și returnează datele.
    """
    serializer_class = SubjectSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    pagination_class = SubjectPageNumberPagination
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['title']

    def get_queryset(self, *args, **kwargs):
        queryset_list = Subject.get_subjects()

        user_query = self.request.GET.get('user', '')
        board_query = self.request.GET.get('board', '')
        trending_subjects = self.request.GET.get('trending', '')

        if user_query:
            queryset_list = queryset_list.filter(author__username__icontains=user_query, )
        if board_query:
            queryset_list = queryset_list.filter(board__slug__icontains=board_query)
        if trending_subjects == "True":
            queryset_list = queryset_list.order_by('-rank_score')

        return queryset_list

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)


class SubjectRetrieveUpdateDestroyAPIView(RetrieveUpdateDestroyAPIView):
    """
    Vizualizare care preia, actualizează sau șterge (dacă utilizatorul este autorul) subiectul..
    """
    queryset = Subject.objects.all()
    serializer_class = SubjectSerializer
    permission_classes = [IsAuthenticatedOrReadOnly, IsAuthorOrReadOnly]
    lookup_field = 'slug'
    lookup_url_kwarg = 'slug'

    def perform_update(self, serializer):
        serializer.save(author=self.request.user)


class StarSubjectView(APIView):
    def get(self, request, format=None):
        """
    Vizualizare care marchează / desmarcă un subiect și returnează starea acțiunii și numărul total de puncte.
        """
        data = dict()
        user = request.user
        subject_slug = request.GET.get('subject_slug')
        subject = Subject.objects.get(slug=subject_slug)
        user = request.user
        if subject in user.liked_subjects.all():
            subject.points.remove(user)
            data['is_starred'] = False
        else:
            subject.points.add(user)
            data['is_starred'] = True

        data['total_points'] = subject.points.count()
        return Response(data)


class ActiveThreadsList(APIView):
    def get(self, request, format=None):
        """Returnează o listă de discuții active.."""
        current_user = request.user
        active_threads = current_user.posted_subjects.all()[:5]
        active_threads_list = [{
            'title': thread.title,
            'slug': thread.slug,
            'board_slug': thread.board.slug
        } for thread in active_threads]
        return Response(active_threads_list)
