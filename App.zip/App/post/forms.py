
from django import forms

from boards.models import Board

from .models import Subject


class SubjectForm(forms.ModelForm):
    """
    Formular care gestionează datele subiectului.
    """
    def get_subscribed_boards(self):
        """Întoarce o listă cu grupuri abonate ale utilizatorului"""
        return self.user.subscribed_boards

    title = forms.CharField(help_text="Poți menționa alți membri în postare tău i.e <b>u/username</b>")
    body = forms.CharField(widget=forms.Textarea(attrs={'rows': 5}), required=False)
    board = forms.ModelChoiceField(queryset=Board.objects.all())

    def __init__(self, *args, **kwargs):
        """
        Inițializați formularul prin popularea opțiunilor de grupuri cu
                forumurile abonate de utilizator.
        """
        user = kwargs.pop('user', None)
        super(SubjectForm, self).__init__(*args, **kwargs)
        if user is not None:
            subscribed_boards = user.subscribed_boards.all()
            self.fields['board'].queryset = subscribed_boards
            if not subscribed_boards:
                self.fields['board'].help_text = "Trebuie să te <b>abonat</b> la un forum pentru a posta în el"

    class Meta:
        model = Subject
        fields = ('title', 'body', 'photo', 'board')
