
from django.contrib.auth import get_user_model
from django.db.models import Q

from rest_framework import serializers
from rest_framework_jwt.settings import api_settings

jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
jwt_response_payload_handler = api_settings.JWT_RESPONSE_PAYLOAD_HANDLER

User = get_user_model()


class CurrentUserDetailSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă detaliile unui utilizator curent.
    """

    screen_name = serializers.SerializerMethodField()
    profile_picture = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'username',
            'screen_name',
            'profile_picture',
        ]

    def get_screen_name(self, obj):
        """
        Returnează numele de ecran al utilizatorului.
        """
        return obj.profile.screen_name()

    def get_profile_picture(self, obj):
        """
        Returnează link-ul cu imaginea de profil a utilizatorului.

        """
        request = self.context.get('request')
        profile_picture_url = obj.profile.get_picture()
        return request.build_absolute_uri(profile_picture_url)


class UserDetailSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă detaliile unui utilizator.
    """

    screen_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['screen_name', 'username']

    def get_screen_name(self, obj):
        """
        Returnează numele de ecran al utilizatorului.
        """
        return obj.profile.screen_name()


class UserLoginSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă un proces de autentificare a unui utilizator.
    """

    token = serializers.CharField(allow_blank=True, read_only=True)
    username = serializers.CharField()

    class Meta:
        model = User
        fields = ['username', 'password', 'token']
        extra_kwargs = {"password": {"write_only": True}}

    def validate(self, data):
        """
        Validează datele utilizatorului și returnează token-ul în cazul în care acreditările furnizate sunt corecte.

        """
        username = data['username']
        password = data['password']
        user_qs = User.objects.filter(Q(username__iexact=username) | Q(email__iexact=username)).distinct()
        if user_qs.exists() and user_qs.count() == 1:
            user_obj = user_qs.first()
            if user_obj.check_password(password):
                user = user_obj
                payload = jwt_payload_handler(user)
                token = jwt_encode_handler(payload)
                data['token'] = token
            else:
                raise serializers.ValidationError("Parolă incorectă.")
        else:
            raise serializers.ValidationError("Utilizatorul cu acest nume de utilizator nu există.")
        return data


class UserSerializerWithToken(serializers.ModelSerializer):
    """
    Serializator care reprezintă înregistrarea unui utilizator.
    """

    token = serializers.SerializerMethodField()
    password = serializers.CharField(write_only=True)

    def get_token(self, obj):


        payload = jwt_payload_handler(obj)
        token = jwt_encode_handler(payload)
        return token

    def create(self, validated_data):
        """
        Gestionează crearea unui utilizator

        """
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance

    class Meta:
        model = User
        fields = [
            'token',
            'username',
            'email',
            'password',
        ]


class ProfileRetrieveSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă un profil..
    """
    profile_picture_url = serializers.SerializerMethodField()
    screen_name = serializers.SerializerMethodField()
    requester_in_contact_list = serializers.SerializerMethodField()
    requester_in_pending_list = serializers.SerializerMethodField()
    has_followed = serializers.SerializerMethodField()
    is_requesters_profile = serializers.SerializerMethodField()
    created_boards_count = serializers.SerializerMethodField()
    posted_subjects_count = serializers.SerializerMethodField()
    boards_subsribed_count = serializers.SerializerMethodField()
    member_since = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'profile_picture_url',
            'screen_name',
            'requester_in_contact_list',
            'requester_in_pending_list',
            'has_followed',
            'is_requesters_profile',
            'created_boards_count',
            'posted_subjects_count',
            'boards_subsribed_count',
            'member_since',
        ]

    def get_profile_picture_url(self, obj):
        """
        Returnează url-ul imaginii de profil a utilizatorului.

        """
        request = self.context.get('request')
        profile_picture_url = obj.profile.get_picture()
        return request.build_absolute_uri(profile_picture_url)

    def get_screen_name(self, obj):
        """
        Returnează numele de ecran al utilizatorului.

        """
        return obj.profile.screen_name()

    def get_requester_in_contact_list(self, obj):
        """
        Verifică dacă solicitantul se află în lista de contacte a utilizatorului.
        """
        user = None
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            user = request.user
        if user in obj.profile.contact_list.all():
            return True
        return False

    def get_requester_in_pending_list(self, obj):
        """
       Verifică dacă solicitantul se află în lista de cereri în așteptare a utilizatorului.
        """
        user = None
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            user = request.user
        if user in obj.profile.pending_list.all():
            return True
        return False

    def get_is_requesters_profile(self, obj):

        user = None
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            user = request.user
        if user == obj:
            return True
        return False

    def get_has_followed(self, obj):
        """
        Verifică dacă solicitantul a urmărit utilizatorul.
        """
        user = None
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            user = request.user
        if user in obj.profile.followers.all():
            return True
        return False

    def get_created_boards_count(self, obj):
        """
        Numără grupurile create de utilizator.
        """
        return obj.inspected_boards.count()

    def get_posted_subjects_count(self, obj):
        """
        Numără subiectele postate de utilizator.
        """
        return obj.posted_subjects.count()

    def get_boards_subsribed_count(self, obj):
        """
        Numără grupurile abonate ale utilizatorului.

        """
        return obj.subscribed_boards.count()

    def get_member_since(self, obj):

        return obj.profile.member_since.date()
