
from django import forms
from django.contrib.auth.models import User

from .models import Profile


class SignupForm(forms.ModelForm):
    """
    Formular care gestionează datele de înscriere.
    """
    class Meta:
        model = User
        fields = ('username', 'email', 'password')


class UserEditForm(forms.ModelForm):
    """
    Formular care gestionează datele utilizatorului.
    """
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')


class ProfileEditForm(forms.ModelForm):
    """
    Form that handles profile data.
    """
    class Meta:
        model = Profile
        fields = ('dob', 'dp')
