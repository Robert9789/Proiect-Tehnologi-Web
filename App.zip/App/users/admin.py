
from django.contrib import admin

from .models import Profile


class ProfileAdmin(admin.ModelAdmin):
    """
    Setări de admin pentru profiluri.
    """
    list_display = ('user', 'dob', 'member_since')
    date_hierarchy = 'member_since'


admin.site.register(Profile, ProfileAdmin)  # noqa: E305
