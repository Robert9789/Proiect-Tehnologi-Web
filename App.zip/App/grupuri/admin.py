
from django.contrib import admin
from .models import Board
class BoardAdmin(admin.ModelAdmin):
    """
    Setări administrative pentru grupuri.
    """
    list_display = ('title', 'created', 'updated')
    date_hierarchy = 'created'


admin.site.register(Board, BoardAdmin)  # noqa: E305
