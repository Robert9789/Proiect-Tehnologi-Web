
from django import forms
from .models import Comment


class CommentForm(forms.ModelForm):
    """
    Formular care gestionează datele privind comentariile.
    """
    class Meta:
        model = Comment
        fields = ('body', )
