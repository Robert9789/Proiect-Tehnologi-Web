from django.apps import AppConfig

class MessengerConfig(AppConfig):
    name = 'messenger'
