
from django.contrib.auth.models import User
from django.contrib.humanize.templatetags.humanize import naturaltime
from rest_framework import serializers
from messenger.models import Message
from users.api.serializers import UserDetailSerializer

class ContactsListSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă lista de contacte a unui utilizator.
    """

    screen_name = serializers.SerializerMethodField()
    profile_picture = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'screen_name',
            'profile_picture',
        ]

    def get_screen_name(self, obj):
        """
        Returns user screen name.
        """
        return obj.profile.screen_name()

    def get_profile_picture(self, obj):
        """
        Returnează link-ul cu imaginea de profil a utilizatorului.

        :return: string
        """
        request = self.context.get('request')
        profile_picture_url = obj.profile.get_picture()
        return request.build_absolute_uri(profile_picture_url)


class MessageListSerializer(serializers.ModelSerializer):
    """
    Serializator care reprezintă mesaje.
    """

    from_user = ContactsListSerializer(read_only=True)
    data_naturaltime = serializers.SerializerMethodField()

    class Meta:
        model = Message
        fields = [
            'id',
            'from_user',
            'message',
            'date',
            'data_naturaltime',
        ]

    def get_data_naturaltime(self, obj):
        """
        Returnează ora
        """
        return naturaltime(obj.date)
