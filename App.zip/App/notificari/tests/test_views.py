
from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from boards.models import Board
from subjects.models import Subject
from django.urls import reverse
from ..models import Notification


class TestNotificationsViews(TestCase):
    """
    Clasa TestCase pentru a testa vizualizările notificărilor.
    """
    def setUp(self):
        # Acest client va fi logat, administrator și abonat la `grupuri`.
        self.client = Client()
        self.user = get_user_model().objects.create_user(username='test_user',
                                                         email='test@gmail.com',
                                                         password='top_secret')
        self.client.login(username='test_user', password='top_secret')
        # Un alt client logat.
        self.other_client = Client()
        self.other_user = get_user_model().objects.create_user(username='other_test_user',
                                                               email='other_test@gmail.com',
                                                               password='top_secret')
        self.other_client.login(username='other_test_user', password='top_secret')
        # Client anonim.
        self.anonymous_client = Client()

        self.board = Board.objects.create(title='test title', description='some random words')
        #`user` administratorul și abonatul.
        self.board.admins.add(self.user)
        self.board.subscribers.add(self.user)

        self.subject = Subject.objects.create(title='test title',
                                              body='some random words',
                                              author=self.user,
                                              board=self.board)
        self.notification = Notification.objects.create(Actor=self.user,
                                                        Object=self.subject,
                                                        Target=self.other_user,
                                                        notif_type="comment")

    def test_activities_page_view(self):
        """Test vizualizare paginii de activități."""""""
        """Test to check notifications via ajax."""

